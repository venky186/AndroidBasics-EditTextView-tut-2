package com.example.edittexttut;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText editText = findViewById(R.id.edt);
        TextView textView = findViewById(R.id.text);
        Button submit = findViewById(R.id.submit_button);
        //Set Some Text To text View
        textView.setText("Text View Data");
        //Initially hide the button
        submit.setVisibility(View.INVISIBLE);
        //How to get the edittext data
        //editText.getText();

        //Lets create the click listener for button
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //We have problem here that soft keyboard is not closing automatically
                //lets close keyboard
                closeKeyBoard();
                //read the Edit text data and add to text view
                String text = editText.getText().toString();
                if (text != null) {
                    textView.setText(text);
                }
            }
        });
        //I dont want to click submit but user need to check the text view while user is editing
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //may be we will make button not visible

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String text = editText.getText().toString();
                if (text != null) {
                    textView.setText(text);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //may be we will make button  visible
                submit.setVisibility(View.VISIBLE);
            }
        });


    }

    /**
     * This Api allows to close the soft Keyboard
     */
    private void closeKeyBoard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager input = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            input.hideSoftInputFromWindow(view.getWindowToken(), 0);

        }
    }
}